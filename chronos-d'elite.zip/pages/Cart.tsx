
import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Trash2, Plus, Minus, ArrowRight, ShoppingBag } from 'lucide-react';

const Cart: React.FC = () => {
  const { cart, removeFromCart, updateQuantity, formatPrice } = useApp();
  
  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const shipping = subtotal > 10000 ? 0 : 50;
  const total = subtotal + shipping;

  if (cart.length === 0) {
    return (
      <div className="pt-48 pb-32 px-4 text-center min-h-screen flex flex-col items-center justify-center bg-black">
        <ShoppingBag size={64} className="text-gray-700 mb-8" />
        <h2 className="text-4xl mb-6">Your Collection is Empty</h2>
        <p className="text-gray-500 mb-10 max-w-sm mx-auto">Explore our prestigious timepieces and find the perfect addition to your legacy.</p>
        <Link to="/shop" className="px-12 py-5 gold-bg text-black font-bold uppercase tracking-widest text-xs transition hover:scale-105 active:scale-95">Explore Collection</Link>
      </div>
    );
  }

  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl mb-16 italic serif">Shopping Collection</h1>
        
        <div className="flex flex-col lg:flex-row gap-16">
          <div className="flex-grow space-y-10">
            {cart.map(item => (
              <div key={item.id} className="flex gap-8 pb-10 border-b border-white/5 group">
                <div className="w-32 sm:w-48 aspect-[4/5] bg-neutral-900 overflow-hidden shrink-0">
                  <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover transition group-hover:scale-105" />
                </div>
                <div className="flex-grow flex flex-col justify-between py-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-[10px] tracking-widest uppercase text-gray-500 mb-2">{item.brand}</h4>
                      <h3 className="text-xl mb-2 text-white">{item.name}</h3>
                      <p className="text-[#bf953f] font-light tracking-widest">{formatPrice(item.price)}</p>
                    </div>
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="text-gray-600 hover:text-red-500 transition p-2"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                  
                  <div className="flex items-center space-x-6">
                    <div className="flex items-center border border-white/10 rounded overflow-hidden">
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-3 text-gray-500 hover:text-white transition"
                      >
                        <Minus size={16} />
                      </button>
                      <span className="w-10 text-center text-sm font-bold text-white">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-3 text-gray-500 hover:text-white transition"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                    <p className="text-sm text-gray-400 uppercase tracking-widest font-bold">Total: {formatPrice(item.price * item.quantity)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <aside className="w-full lg:w-96">
            <div className="bg-neutral-900/50 border border-white/5 p-8 rounded-lg sticky top-32">
              <h3 className="text-xl mb-8 uppercase tracking-widest font-bold">Summary</h3>
              
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Subtotal</span>
                  <span className="text-white tracking-widest">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Estimated Shipping</span>
                  <span className="text-white tracking-widest">{shipping === 0 ? 'Complimentary' : formatPrice(shipping)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">VAT (Tax)</span>
                  <span className="text-white tracking-widest">Calculated at checkout</span>
                </div>
              </div>
              
              <div className="border-t border-white/10 pt-6 mb-10 flex justify-between items-baseline">
                <span className="text-lg font-bold uppercase tracking-widest">Total</span>
                <span className="text-2xl font-light text-[#bf953f] tracking-widest">{formatPrice(total)}</span>
              </div>

              <Link 
                to="/checkout" 
                className="w-full bg-[#bf953f] text-black h-16 flex items-center justify-center font-bold uppercase tracking-widest text-xs transition hover:bg-[#d4af37] active:scale-95 gap-3"
              >
                Proceed to Checkout <ArrowRight size={18} />
              </Link>
              
              <div className="mt-8 text-center">
                <p className="text-[10px] text-gray-500 uppercase tracking-widest">White-Glove Delivery Guaranteed</p>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

export default Cart;
