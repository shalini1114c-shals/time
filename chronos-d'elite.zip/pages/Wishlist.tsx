
import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { products } from '../data/products';
import { Heart, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';

const Wishlist: React.FC = () => {
  const { wishlist, toggleWishlist, addToCart, formatPrice } = useApp();
  
  const wishlistedProducts = products.filter(p => wishlist.includes(p.id));

  if (wishlistedProducts.length === 0) {
    return (
      <div className="pt-48 pb-32 px-4 text-center min-h-screen flex flex-col items-center justify-center bg-black">
        <div className="relative mb-8">
          <Heart size={64} className="text-gray-800" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-1 h-1 bg-[#bf953f] rounded-full animate-ping"></div>
          </div>
        </div>
        <h2 className="text-4xl mb-6 italic serif">Your Wishlist is Empty</h2>
        <p className="text-gray-500 mb-10 max-w-sm mx-auto uppercase tracking-widest text-[10px]">
          Curate your personal collection of the world's finest timepieces.
        </p>
        <Link to="/shop" className="px-12 py-5 gold-bg text-black font-bold uppercase tracking-widest text-xs transition hover:scale-105 active:scale-95">
          Begin Curating
        </Link>
      </div>
    );
  }

  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto">
        <header className="mb-16">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Personal Selection</span>
          <h1 className="text-4xl md:text-5xl italic serif">Your Wishlist</h1>
        </header>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-12">
          {wishlistedProducts.map(product => (
            <div key={product.id} className="group relative">
              <div className="relative aspect-[4/5] bg-neutral-900 overflow-hidden mb-6">
                <Link to={`/product/${product.id}`}>
                  <img 
                    src={product.images[0]} 
                    alt={product.name}
                    className="w-full h-full object-cover transition duration-1000 group-hover:scale-110 opacity-80 group-hover:opacity-100"
                  />
                </Link>
                <button 
                  onClick={() => toggleWishlist(product.id)}
                  className="absolute top-4 right-4 p-3 bg-black/60 backdrop-blur-md text-[#bf953f] rounded-full hover:bg-black transition"
                  title="Remove from wishlist"
                >
                  <Trash2 size={16} />
                </button>
              </div>

              <div className="flex flex-col">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="text-[10px] tracking-[0.3em] uppercase text-gray-500 mb-1">{product.brand}</h4>
                    <h3 className="text-lg text-white group-hover:text-[#bf953f] transition">
                      <Link to={`/product/${product.id}`}>{product.name}</Link>
                    </h3>
                  </div>
                  <span className="text-sm font-light text-[#bf953f] tracking-widest">
                    {formatPrice(product.price)}
                  </span>
                </div>
                
                <p className="text-gray-500 text-xs font-light line-clamp-2 mb-6 h-8">
                  {product.description}
                </p>

                <div className="flex gap-4">
                  <button 
                    onClick={() => addToCart(product)}
                    className="flex-grow bg-[#bf953f] text-black py-4 flex items-center justify-center font-bold uppercase tracking-widest text-[10px] transition hover:bg-[#d4af37] active:scale-95 gap-2"
                  >
                    <ShoppingBag size={14} /> Add to Cart
                  </button>
                  <Link 
                    to={`/product/${product.id}`}
                    className="w-12 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:border-white transition"
                  >
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-24 pt-12 border-t border-white/5 text-center">
          <p className="text-gray-500 text-xs uppercase tracking-[0.4em] mb-8">Ready to complete your collection?</p>
          <Link to="/cart" className="inline-flex items-center gap-4 text-[#bf953f] font-bold uppercase tracking-widest text-xs hover:gap-6 transition-all">
            View Shopping Bag <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Wishlist;
