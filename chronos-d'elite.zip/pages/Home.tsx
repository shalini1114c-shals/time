
import React from 'react';
import { Link } from 'react-router-dom';
import { products } from '../data/products';
import { ArrowRight, Star } from 'lucide-react';
import { useApp } from '../context/AppContext';

const Home: React.FC = () => {
  const { formatPrice, recentlyViewed } = useApp();
  const featured = products.filter(p => p.featured).slice(0, 3);
  const bestSellers = products.filter(p => p.bestSeller).slice(0, 4);
  const recentlyViewedProducts = products.filter(p => recentlyViewed.includes(p.id)).slice(0, 4);

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1619134778706-7015533a6150?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover opacity-60 animate-slow-zoom"
            alt="Luxury Watch Background"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <span className="text-xs uppercase tracking-[0.6em] text-[#bf953f] mb-6 block opacity-0 animate-[fadeIn_1s_ease-out_forwards]">EST. 1924 | GENEVA</span>
          <h1 className="text-5xl md:text-8xl mb-8 leading-tight opacity-0 animate-[fadeIn_1s_ease-out_0.5s_forwards]">
            Timeless Luxury <br /> <span className="italic serif">on Your Wrist</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-300 mb-10 max-w-2xl mx-auto font-light tracking-wide opacity-0 animate-[fadeIn_1s_ease-out_1s_forwards]">
            Discover a curated collection of horological masterpieces from the world's most prestigious maisons.
          </p>
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 opacity-0 animate-[fadeIn_1s_ease-out_1.5s_forwards]">
            <Link 
              to="/shop" 
              className="px-10 py-4 gold-bg text-black font-bold uppercase tracking-widest text-xs transition hover:scale-105 active:scale-95"
            >
              Explore Collection
            </Link>
            <Link 
              to="/shop?collection=Limited" 
              className="px-10 py-4 border border-white/20 text-white font-bold uppercase tracking-widest text-xs transition hover:bg-white/10"
            >
              View Limited Editions
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Collections */}
      <section className="py-32 px-4 bg-black">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Link to="/shop?collection=Men" className="group relative h-[600px] overflow-hidden">
              <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=1000" className="w-full h-full object-cover transition duration-1000 group-hover:scale-110" alt="Men's" />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition duration-500"></div>
              <div className="absolute bottom-12 left-12">
                <h3 className="text-4xl text-white mb-4">The Gentleman</h3>
                <span className="flex items-center text-xs tracking-[0.3em] uppercase text-white font-bold">
                  Discover Men <ArrowRight className="ml-2 group-hover:translate-x-2 transition" size={16} />
                </span>
              </div>
            </Link>
            <Link to="/shop?collection=Women" className="group relative h-[600px] overflow-hidden">
              <img src="https://images.unsplash.com/photo-1509048191080-d2984bad6ad5?auto=format&fit=crop&q=80&w=1000" className="w-full h-full object-cover transition duration-1000 group-hover:scale-110" alt="Women's" />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition duration-500"></div>
              <div className="absolute bottom-12 left-12">
                <h3 className="text-4xl text-white mb-4">Grace & Elegance</h3>
                <span className="flex items-center text-xs tracking-[0.3em] uppercase text-white font-bold">
                  Discover Women <ArrowRight className="ml-2 group-hover:translate-x-2 transition" size={16} />
                </span>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Best Sellers Carousel Section */}
      <section className="py-24 px-4 bg-neutral-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-16">
            <div>
              <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Our Icons</span>
              <h2 className="text-4xl md:text-5xl">Best Sellers</h2>
            </div>
            <Link to="/shop" className="text-sm font-bold uppercase tracking-widest border-b border-[#bf953f] pb-1 hover:text-[#bf953f] transition">Shop All</Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {bestSellers.map(product => (
              <Link key={product.id} to={`/product/${product.id}`} className="group">
                <div className="relative aspect-[4/5] bg-neutral-900 overflow-hidden mb-6">
                  <img 
                    src={product.images[0]} 
                    alt={product.name}
                    className="w-full h-full object-cover transition duration-700 group-hover:scale-105"
                  />
                  {product.category === 'Limited Edition' && (
                    <span className="absolute top-4 left-4 bg-black/80 backdrop-blur px-3 py-1 text-[10px] tracking-widest text-[#bf953f] uppercase border border-[#bf953f]/30">Limited</span>
                  )}
                </div>
                <h4 className="text-xs tracking-widest uppercase text-gray-400 mb-1">{product.brand}</h4>
                <h3 className="text-lg mb-2 group-hover:text-[#bf953f] transition">{product.name}</h3>
                <p className="text-sm font-semibold tracking-wide">{formatPrice(product.price)}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Recently Viewed Section */}
      {recentlyViewedProducts.length > 0 && (
        <section className="py-24 px-4 bg-black">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-end mb-16">
              <div>
                <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Continue Exploring</span>
                <h2 className="text-4xl md:text-5xl italic serif">Recently Viewed</h2>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {recentlyViewedProducts.map(product => (
                <Link key={product.id} to={`/product/${product.id}`} className="group">
                  <div className="relative aspect-[4/5] bg-neutral-900 overflow-hidden mb-6">
                    <img 
                      src={product.images[0]} 
                      alt={product.name}
                      className="w-full h-full object-cover transition duration-700 group-hover:scale-105"
                    />
                  </div>
                  <h4 className="text-xs tracking-widest uppercase text-gray-400 mb-1">{product.brand}</h4>
                  <h3 className="text-lg mb-2 group-hover:text-[#bf953f] transition">{product.name}</h3>
                  <p className="text-sm font-semibold tracking-wide">{formatPrice(product.price)}</p>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Brand Story */}
      <section className="py-32 px-4 bg-black">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="relative">
            <img src="https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?auto=format&fit=crop&q=80&w=800" className="w-full h-[600px] object-cover" alt="Heritage" />
            <div className="absolute -bottom-10 -right-10 w-64 h-64 border-4 border-[#bf953f] -z-10 hidden lg:block"></div>
          </div>
          <div>
            <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-6 block">Our Legacy</span>
            <h2 className="text-5xl mb-8 leading-tight italic serif">Century of Precision</h2>
            <p className="text-gray-400 text-lg mb-8 font-light leading-relaxed">
              Founded in the heart of the Swiss Jura mountains, Chronos d'Elite has been synonymous with horological innovation and craftsmanship for over a hundred years.
            </p>
            <p className="text-gray-400 text-lg mb-12 font-light leading-relaxed">
              Each timepiece is a testament to our dedication to perfection, blending traditional watchmaking techniques with cutting-edge technology.
            </p>
            <Link to="/about" className="inline-block px-12 py-5 border border-white/20 text-xs font-bold uppercase tracking-widest hover:bg-[#bf953f] hover:text-black hover:border-transparent transition">Discover Our History</Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-4 bg-neutral-900/50">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center space-x-1 mb-8">
            {[1, 2, 3, 4, 5].map(i => <Star key={i} size={16} fill="#bf953f" color="#bf953f" />)}
          </div>
          <p className="text-2xl md:text-3xl italic serif mb-10 leading-relaxed text-gray-200">
            "The level of service and the exquisite collection at Chronos d'Elite is simply unparalleled. My Patek Philippe is a treasure I will pass down for generations."
          </p>
          <div className="flex flex-col items-center">
            <img src="https://picsum.photos/id/64/100/100" className="w-16 h-16 rounded-full mb-4 object-cover" alt="Avatar" />
            <h4 className="text-sm font-bold tracking-widest uppercase">Alexander Rothschild</h4>
            <span className="text-[10px] text-gray-500 uppercase tracking-widest">Venture Capitalist</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
