
import React from 'react';
import { ShieldCheck, FileText, Fingerprint, Award, CheckCircle2 } from 'lucide-react';

const AuthenticityCertification: React.FC = () => {
  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-20">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Proof of Excellence</span>
          <h1 className="text-4xl md:text-6xl italic serif mb-8">Authenticity & Certification</h1>
          <p className="text-gray-500 font-light text-lg leading-relaxed">
            Every masterpiece tells a story. We ensure yours is genuine, verified, and protected by the highest standards of horological certification.
          </p>
        </header>

        <section className="mb-24">
          <div className="relative h-96 mb-16 overflow-hidden rounded-lg border border-white/5">
            <img 
              src="https://images.unsplash.com/photo-1509048191080-d2984bad6ad5?auto=format&fit=crop&q=80&w=1200" 
              className="w-full h-full object-cover opacity-40 grayscale"
              alt="Verification Process"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-black/60 backdrop-blur-md p-8 border border-[#bf953f]/30 text-center">
                <Fingerprint size={48} className="text-[#bf953f] mx-auto mb-4" />
                <h3 className="text-xl uppercase tracking-widest font-bold">The Digital Passport</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-widest mt-2">NFC-Enabled Blockchain Verification</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-2xl italic serif mb-6">Valuation Services</h2>
              <p className="text-gray-400 font-light leading-relaxed mb-6 text-sm">
                Our resident appraisers provide detailed valuation reports for insurance, inheritance, or private sale. Each report includes a comprehensive analysis of the movement condition, component originality, and current market positioning.
              </p>
              <ul className="space-y-4">
                {[
                  "Component-level inspection",
                  "Historical provenance research",
                  "Global market value analysis",
                  "Digital archive registration"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-xs uppercase tracking-widest text-gray-500">
                    <CheckCircle2 size={14} className="text-[#bf953f]" /> {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-neutral-900/40 p-10 border border-white/5 luxury-shadow">
              <Award className="text-[#bf953f] mb-6" size={32} />
              <h3 className="text-xl mb-4 font-bold uppercase tracking-widest">Master Certification</h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                Timepieces purchased through Chronos d'Elite undergo a 40-point verification process by our master watchmakers. We certify the accuracy, water resistance, and authenticity of every individual part.
              </p>
            </div>
          </div>
        </section>

        <section className="py-20 border-t border-white/10">
          <div className="text-center mb-12">
            <h2 className="text-3xl italic serif">The Certification Process</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full border border-[#bf953f]/30 flex items-center justify-center mx-auto mb-6">
                <span className="text-[#bf953f] font-serif text-2xl italic">1</span>
              </div>
              <h4 className="text-xs font-bold uppercase tracking-widest mb-3">Submission</h4>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest leading-loose">Secure transport of your timepiece to our Geneva vault.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full border border-[#bf953f]/30 flex items-center justify-center mx-auto mb-6">
                <span className="text-[#bf953f] font-serif text-2xl italic">2</span>
              </div>
              <h4 className="text-xs font-bold uppercase tracking-widest mb-3">Verification</h4>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest leading-loose">Meticulous inspection by certified master horologists.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full border border-[#bf953f]/30 flex items-center justify-center mx-auto mb-6">
                <span className="text-[#bf953f] font-serif text-2xl italic">3</span>
              </div>
              <h4 className="text-xs font-bold uppercase tracking-widest mb-3">Certification</h4>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest leading-loose">Issuance of the Chronos d'Elite Digital Passport.</p>
            </div>
          </div>
        </section>

        <div className="bg-neutral-900/50 p-12 text-center border border-white/5">
          <h3 className="text-xl italic serif mb-6">Ready to certify your legacy?</h3>
          <p className="text-xs text-gray-500 uppercase tracking-widest mb-10">Valuation appointments available in-person or via secure collection.</p>
          <button className="px-12 py-5 gold-bg text-black font-bold uppercase tracking-widest text-xs transition hover:scale-105 active:scale-95">
            Request Valuation
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthenticityCertification;
