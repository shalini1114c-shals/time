
import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, ShieldCheck, PenTool, Sparkles, Fingerprint } from 'lucide-react';

const ServiceRepairs: React.FC = () => {
  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-20">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">The Art of Maintenance</span>
          <h1 className="text-4xl md:text-6xl italic serif mb-8">Service & Repairs</h1>
          <p className="text-gray-500 font-light text-lg leading-relaxed">
            A timepiece from Chronos d'Elite is engineered to last lifetimes. Our master horologists ensure your legacy remains precise.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
          <div className="bg-neutral-900/40 p-10 border border-white/5 luxury-shadow">
            <Clock className="text-[#bf953f] mb-6" size={32} />
            <h3 className="text-xl mb-4 font-bold uppercase tracking-widest">Complete Overhaul</h3>
            <p className="text-sm text-gray-500 leading-relaxed mb-6">
              A comprehensive service involving the complete disassembly of the movement, cleaning of all parts, and meticulous reassembly with fresh lubricants.
            </p>
            <span className="text-[#bf953f] text-xs font-bold uppercase tracking-widest">Recommended every 5 years</span>
          </div>
          <div className="bg-neutral-900/40 p-10 border border-white/5 luxury-shadow">
            <Sparkles className="text-[#bf953f] mb-6" size={32} />
            <h3 className="text-xl mb-4 font-bold uppercase tracking-widest">Restoration & Polishing</h3>
            <p className="text-sm text-gray-500 leading-relaxed mb-6">
              Restore the original luster of your gold or platinum case. Our specialists use traditional techniques to remove imperfections while preserving the watch's geometry.
            </p>
            <span className="text-[#bf953f] text-xs font-bold uppercase tracking-widest">Aesthetic refinement</span>
          </div>
        </div>

        <section className="bg-neutral-900/20 border border-white/5 p-12 mb-24 flex flex-col md:flex-row items-center gap-8">
          <Fingerprint size={48} className="text-[#bf953f] shrink-0" />
          <div className="flex-grow">
            <h3 className="text-xl mb-2 italic serif">Authenticity Verification</h3>
            <p className="text-sm text-gray-500 mb-6">Secure your investment with our official authentication service and digital passport registration.</p>
            <Link to="/authenticity" className="text-[10px] font-bold uppercase tracking-widest text-[#bf953f] border-b border-[#bf953f]/30 pb-1 hover:text-white hover:border-white transition">Explore Certification</Link>
          </div>
        </section>

        <section className="space-y-12 mb-24">
          <h2 className="text-2xl italic serif border-b border-white/10 pb-4">Our Commitment</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center">
              <ShieldCheck className="text-[#bf953f] mb-4" />
              <h4 className="text-[10px] font-bold uppercase tracking-widest mb-2">Authenticated Parts</h4>
              <p className="text-[10px] text-gray-600 uppercase tracking-widest">Only genuine components from original manufactures.</p>
            </div>
            <div className="flex flex-col items-center">
              <PenTool className="text-[#bf953f] mb-4" />
              <h4 className="text-[10px] font-bold uppercase tracking-widest mb-2">Certified Horologists</h4>
              <p className="text-[10px] text-gray-600 uppercase tracking-widest">Our masters are trained in Geneva and Le Sentier.</p>
            </div>
            <div className="flex flex-col items-center">
              <Clock className="text-[#bf953f] mb-4" />
              <h4 className="text-[10px] font-bold uppercase tracking-widest mb-2">Service Warranty</h4>
              <p className="text-[10px] text-gray-600 uppercase tracking-widest">All services include a 24-month limited warranty.</p>
            </div>
          </div>
        </section>

        <div className="text-center bg-[#bf953f]/5 p-12 rounded border border-[#bf953f]/20">
          <p className="text-sm uppercase tracking-[0.3em] mb-8 text-gray-400">Request a collection or visit a boutique</p>
          <button className="px-12 py-5 gold-bg text-black font-bold uppercase tracking-widest text-xs transition hover:scale-105 active:scale-95">
            Book a Consultation
          </button>
        </div>
      </div>
    </div>
  );
};

export default ServiceRepairs;
