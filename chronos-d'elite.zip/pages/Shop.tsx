
import React, { useState, useEffect, useMemo } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { products } from '../data/products';
import { Filter, SlidersHorizontal, Sparkles, Loader2, X, Heart, ShoppingBag } from 'lucide-react';
import { getWatchRecommendation } from '../services/geminiService';
import { Product } from '../types';
import { useApp } from '../context/AppContext';

const Shop: React.FC = () => {
  const { formatPrice, wishlist, toggleWishlist, addToCart } = useApp();
  const location = useLocation();
  const [activeFilters, setActiveFilters] = useState({
    gender: '',
    category: '',
    brand: '',
    priceRange: [0, 500000]
  });
  const [sortBy, setSortBy] = useState('newest');
  
  // AI State
  const [aiStyle, setAiStyle] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiRecommendation, setAiRecommendation] = useState<any>(null);
  const [showAiModal, setShowAiModal] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const collection = params.get('collection');
    const category = params.get('category');
    
    if (collection) setActiveFilters(prev => ({ ...prev, gender: collection }));
    if (category) setActiveFilters(prev => ({ ...prev, category: category }));
  }, [location]);

  const filteredProducts = useMemo(() => {
    return products
      .filter(p => {
        if (activeFilters.gender && p.gender !== activeFilters.gender) return false;
        if (activeFilters.category && p.category !== activeFilters.category) return false;
        if (activeFilters.brand && p.brand !== activeFilters.brand) return false;
        if (p.price < activeFilters.priceRange[0] || p.price > activeFilters.priceRange[1]) return false;
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-low') return a.price - b.price;
        if (sortBy === 'price-high') return b.price - a.price;
        return 0; // default newest
      });
  }, [activeFilters, sortBy]);

  const handleAiConsult = async () => {
    if (!aiStyle.trim()) return;
    setIsAiLoading(true);
    const rec = await getWatchRecommendation(aiStyle, products);
    setAiRecommendation(rec);
    setIsAiLoading(false);
    setShowAiModal(true);
  };

  return (
    <div className="pt-32 pb-24 px-4 min-h-screen bg-black">
      <div className="max-w-7xl mx-auto">
        <header className="mb-16 text-center">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">The Collection</span>
          <h1 className="text-5xl md:text-7xl mb-8">Horological <span className="italic serif text-gray-300">Masterpieces</span></h1>
          <p className="max-w-2xl mx-auto text-gray-500 font-light text-lg">
            Discover precision and passion in every movement.
          </p>
        </header>

        {/* AI Concierge Bar */}
        <div className="bg-neutral-900/50 border border-[#bf953f]/20 rounded-lg p-6 mb-16 flex flex-col md:flex-row items-center gap-6 luxury-shadow">
          <div className="flex items-center text-[#bf953f] gap-3 shrink-0">
            <Sparkles size={24} />
            <span className="text-xs font-bold uppercase tracking-widest">AI Concierge</span>
          </div>
          <div className="flex-grow relative w-full">
            <input 
              type="text" 
              value={aiStyle}
              onChange={(e) => setAiStyle(e.target.value)}
              placeholder="Tell us about your style or the occasion (e.g. 'I need a watch for a black-tie gala')..."
              className="w-full bg-black/50 border border-white/10 rounded px-4 py-3 text-sm focus:border-[#bf953f] outline-none"
            />
          </div>
          <button 
            onClick={handleAiConsult}
            disabled={isAiLoading}
            className="shrink-0 bg-[#bf953f] text-black px-8 py-3 rounded font-bold uppercase tracking-widest text-xs transition hover:bg-[#d4af37] disabled:opacity-50 flex items-center gap-2"
          >
            {isAiLoading ? <Loader2 className="animate-spin" size={16} /> : 'Get Advice'}
          </button>
        </div>

        <div className="flex flex-col lg:flex-row gap-12">
          {/* Filters Sidebar */}
          <aside className="w-full lg:w-64 space-y-10">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-white mb-6 border-b border-white/10 pb-2">Gender</h3>
              <div className="space-y-3">
                {['Men', 'Women', 'Unisex'].map(g => (
                  <label key={g} className="flex items-center cursor-pointer group">
                    <input 
                      type="radio" 
                      name="gender" 
                      className="hidden" 
                      checked={activeFilters.gender === g}
                      onChange={() => setActiveFilters(prev => ({ ...prev, gender: g === prev.gender ? '' : g }))}
                    />
                    <div className={`w-4 h-4 rounded-full border border-white/20 mr-3 flex items-center justify-center ${activeFilters.gender === g ? 'bg-[#bf953f] border-transparent' : 'group-hover:border-[#bf953f]'}`}>
                      {activeFilters.gender === g && <div className="w-1.5 h-1.5 bg-black rounded-full"></div>}
                    </div>
                    <span className={`text-sm tracking-wide ${activeFilters.gender === g ? 'text-white' : 'text-gray-500 hover:text-white'}`}>{g}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-white mb-6 border-b border-white/10 pb-2">Category</h3>
              <div className="space-y-3">
                {['Classic', 'Sport', 'Luxury', 'Limited Edition'].map(c => (
                  <button 
                    key={c}
                    onClick={() => setActiveFilters(prev => ({ ...prev, category: c === prev.category ? '' : c }))}
                    className={`block text-sm text-left transition ${activeFilters.category === c ? 'text-[#bf953f] font-bold' : 'text-gray-500 hover:text-white'}`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-white/10">
              <button 
                onClick={() => setActiveFilters({ gender: '', category: '', brand: '', priceRange: [0, 500000] })}
                className="text-[10px] uppercase tracking-widest font-bold text-gray-500 hover:text-white underline underline-offset-4"
              >
                Reset All Filters
              </button>
            </div>
          </aside>

          {/* Product Grid */}
          <main className="flex-grow">
            <div className="flex justify-between items-center mb-10 pb-4 border-b border-white/10">
              <p className="text-sm text-gray-500 italic">{filteredProducts.length} Timepieces Found</p>
              <div className="flex items-center gap-4">
                <span className="text-[10px] font-bold uppercase tracking-widest text-gray-500">Sort By:</span>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-transparent border-none text-xs font-bold uppercase tracking-widest text-[#bf953f] outline-none cursor-pointer"
                >
                  <option value="newest">New Arrivals</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-16">
              {filteredProducts.map(product => {
                const isWishlisted = wishlist.includes(product.id);
                return (
                  <div key={product.id} className="group relative">
                    <Link to={`/product/${product.id}`} className="block relative aspect-[4/5] bg-neutral-900 overflow-hidden mb-6">
                      <img 
                        src={product.images[0]} 
                        alt={product.name}
                        className="w-full h-full object-cover transition duration-1000 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition"></div>
                      {product.featured && (
                        <span className="absolute top-4 right-4 bg-white/10 backdrop-blur px-3 py-1 text-[9px] tracking-[0.2em] text-white uppercase border border-white/20">Featured</span>
                      )}
                    </Link>
                    
                    {/* Wishlist Button on Grid */}
                    <button 
                      onClick={() => toggleWishlist(product.id)}
                      className={`absolute top-4 left-4 p-2 bg-black/40 backdrop-blur rounded-full transition-all duration-300 hover:bg-black/80 ${isWishlisted ? 'text-[#bf953f]' : 'text-white/60 hover:text-white opacity-0 group-hover:opacity-100'}`}
                      title={isWishlisted ? "Remove from Wishlist" : "Add to Wishlist"}
                    >
                      <Heart size={16} fill={isWishlisted ? "currentColor" : "none"} />
                    </button>

                    <h4 className="text-[10px] tracking-[0.3em] uppercase text-gray-500 mb-2">{product.brand}</h4>
                    <h3 className="text-xl mb-2 group-hover:text-[#bf953f] transition">
                      <Link to={`/product/${product.id}`}>{product.name}</Link>
                    </h3>
                    <div className="flex justify-between items-center">
                      <div className="flex items-baseline gap-4">
                        <span className="text-lg font-light tracking-widest text-[#bf953f]">{formatPrice(product.price)}</span>
                        {product.oldPrice && (
                          <span className="text-sm text-gray-600 line-through tracking-widest">{formatPrice(product.oldPrice)}</span>
                        )}
                      </div>
                      <button 
                        onClick={() => addToCart(product)}
                        className="p-2 text-gray-500 hover:text-[#bf953f] transition"
                        title="Add to Collection"
                      >
                        <ShoppingBag size={20} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {filteredProducts.length === 0 && (
              <div className="text-center py-32 border border-white/5 bg-neutral-900/20 rounded-lg">
                <p className="text-gray-500 text-lg mb-4">No timepieces match your selection.</p>
                <button 
                   onClick={() => setActiveFilters({ gender: '', category: '', brand: '', priceRange: [0, 500000] })}
                   className="text-[#bf953f] uppercase tracking-widest text-xs font-bold border-b border-[#bf953f] pb-1"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* AI Recommendation Modal */}
      {showAiModal && aiRecommendation && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-[#bf953f]/30 max-w-2xl w-full p-8 rounded-lg relative">
            <button 
              onClick={() => setShowAiModal(false)}
              className="absolute top-4 right-4 text-gray-500 hover:text-white transition"
            >
              <X size={24} />
            </button>
            <div className="flex items-center gap-3 text-[#bf953f] mb-6">
              <Sparkles size={24} />
              <h2 className="text-xl uppercase tracking-widest font-bold">Your Personal Recommendations</h2>
            </div>
            <p className="text-gray-300 italic serif mb-8 text-lg leading-relaxed">"{aiRecommendation.conciergeMessage}"</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {aiRecommendation.recommendations.map((rec: any) => {
                const product = products.find(p => p.id === rec.productId);
                if (!product) return null;
                return (
                  <div key={product.id} className="border border-white/10 p-4 rounded bg-black/30 hover:border-[#bf953f]/50 transition">
                    <img src={product.images[0]} className="w-full h-40 object-cover mb-4 rounded" alt={product.name} />
                    <h3 className="text-sm font-bold uppercase mb-2 text-white">{product.name}</h3>
                    <p className="text-xs text-gray-400 mb-4 line-clamp-3">{rec.reason}</p>
                    <Link 
                      to={`/product/${product.id}`} 
                      className="text-[#bf953f] text-[10px] font-bold uppercase tracking-widest border-b border-[#bf953f]/30 pb-0.5 hover:border-[#bf953f] transition"
                    >
                      View Details
                    </Link>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Shop;
