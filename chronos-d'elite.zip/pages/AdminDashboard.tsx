
import React, { useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, AreaChart, Area 
} from 'recharts';
import { 
  LayoutDashboard, Package, ShoppingCart, Users, TrendingUp, 
  Plus, Search, Edit3, Trash2, MoreVertical, DollarSign, ArrowUpRight 
} from 'lucide-react';
import { products as initialProducts } from '../data/products';
import { useApp } from '../context/AppContext';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders'>('overview');
  const [products, setProducts] = useState(initialProducts);
  const { orders, formatPrice, currency } = useApp();

  const analyticsData = [
    { name: 'Mon', revenue: 45000, orders: 3 },
    { name: 'Tue', revenue: 12000, orders: 1 },
    { name: 'Wed', revenue: 85000, orders: 4 },
    { name: 'Thu', revenue: 95000, orders: 2 },
    { name: 'Fri', revenue: 110000, orders: 6 },
    { name: 'Sat', revenue: 210000, orders: 9 },
    { name: 'Sun', revenue: 180000, orders: 7 },
  ];

  const stats = [
    { label: 'Total Revenue', value: formatPrice(737000), change: '+12.5%', icon: DollarSign },
    { label: 'Total Orders', value: '32', change: '+8.2%', icon: ShoppingCart },
    { label: 'Active Customers', value: '1,204', change: '+2.4%', icon: Users },
    { label: 'Inventory Value', value: formatPrice(3400000), change: '+5.1%', icon: Package },
  ];

  return (
    <div className="min-h-screen bg-black pt-24 pb-12 flex">
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/5 shrink-0 hidden md:block">
        <div className="px-8 py-8">
          <h2 className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500 mb-8">Admin Panel</h2>
          <nav className="space-y-4">
            <button 
              onClick={() => setActiveTab('overview')}
              className={`w-full flex items-center gap-4 px-4 py-3 rounded transition ${activeTab === 'overview' ? 'bg-[#bf953f] text-black font-bold' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
            >
              <LayoutDashboard size={18} /> <span className="text-xs uppercase tracking-widest">Overview</span>
            </button>
            <button 
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center gap-4 px-4 py-3 rounded transition ${activeTab === 'products' ? 'bg-[#bf953f] text-black font-bold' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
            >
              <Package size={18} /> <span className="text-xs uppercase tracking-widest">Products</span>
            </button>
            <button 
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center gap-4 px-4 py-3 rounded transition ${activeTab === 'orders' ? 'bg-[#bf953f] text-black font-bold' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
            >
              <ShoppingCart size={18} /> <span className="text-xs uppercase tracking-widest">Orders</span>
            </button>
          </nav>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow px-8 py-8">
        <header className="flex justify-between items-center mb-12">
          <h1 className="text-3xl font-bold uppercase tracking-widest gold-gradient">Dashboard</h1>
          <div className="flex items-center gap-4">
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
              <input 
                type="text" 
                placeholder="Search..." 
                className="bg-neutral-900 border border-white/10 rounded-full pl-10 pr-4 py-2 text-xs focus:border-[#bf953f] outline-none"
              />
            </div>
            <button className="bg-neutral-900 border border-white/10 p-2 rounded-full text-gray-400 hover:text-white transition">
              <Users size={20} />
            </button>
          </div>
        </header>

        {activeTab === 'overview' && (
          <div className="space-y-10">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, idx) => (
                <div key={idx} className="bg-neutral-900/50 border border-white/5 p-6 rounded-lg luxury-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <stat.icon size={24} className="text-[#bf953f]" />
                    <span className="text-green-500 text-[10px] font-bold flex items-center">{stat.change} <ArrowUpRight size={12} className="ml-1" /></span>
                  </div>
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">{stat.label}</h4>
                  <p className="text-2xl font-light tracking-wider">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-neutral-900/50 border border-white/5 p-8 rounded-lg">
                <h3 className="text-sm font-bold uppercase tracking-widest mb-8">Weekly Revenue ({currency})</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={analyticsData}>
                      <defs>
                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#bf953f" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#bf953f" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                      <XAxis dataKey="name" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#666" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => currency === 'INR' ? `₹${(val * 83.5 / 1000).toFixed(0)}k` : `$${val/1000}k`} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#171717', border: '1px solid #333', borderRadius: '4px' }}
                        itemStyle={{ color: '#bf953f' }}
                        formatter={(value: any) => formatPrice(value)}
                      />
                      <Area type="monotone" dataKey="revenue" stroke="#bf953f" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-neutral-900/50 border border-white/5 p-8 rounded-lg">
                <h3 className="text-sm font-bold uppercase tracking-widest mb-8">Daily Orders</h3>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analyticsData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                      <XAxis dataKey="name" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                      <Tooltip 
                        cursor={{ fill: '#ffffff05' }}
                        contentStyle={{ backgroundColor: '#171717', border: '1px solid #333', borderRadius: '4px' }}
                      />
                      <Bar dataKey="orders" fill="#bf953f" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Recent Orders Table Mock */}
            <div className="bg-neutral-900/50 border border-white/5 rounded-lg overflow-hidden">
              <div className="p-6 border-b border-white/5 flex justify-between items-center">
                <h3 className="text-sm font-bold uppercase tracking-widest">Recent Sales</h3>
                <button className="text-[10px] uppercase font-bold text-[#bf953f]">View All</button>
              </div>
              <table className="w-full text-left text-xs uppercase tracking-widest">
                <thead className="bg-black/20 text-gray-500">
                  <tr>
                    <th className="px-6 py-4">Order ID</th>
                    <th className="px-6 py-4">Customer</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {[1, 2, 3].map(i => (
                    <tr key={i} className="hover:bg-white/5 transition">
                      <td className="px-6 py-4 text-white">#CH-982{i}</td>
                      <td className="px-6 py-4 text-gray-400">Client {i}</td>
                      <td className="px-6 py-4">
                        <span className="bg-green-500/10 text-green-500 px-2 py-1 rounded text-[8px] font-bold">Paid</span>
                      </td>
                      <td className="px-6 py-4 text-gray-500">Jan {20 + i}, 2024</td>
                      <td className="px-6 py-4 text-right text-[#bf953f] font-bold">{formatPrice(12000 * i)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="space-y-8">
            <div className="flex justify-between items-center">
              <h3 className="text-xl italic serif">Manage Inventory</h3>
              <button className="bg-[#bf953f] text-black px-6 py-3 rounded font-bold uppercase tracking-widest text-[10px] flex items-center gap-2 hover:bg-[#d4af37] transition">
                <Plus size={16} /> Add New Watch
              </button>
            </div>

            <div className="bg-neutral-900/50 border border-white/5 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs uppercase tracking-widest">
                <thead className="bg-black/20 text-gray-500">
                  <tr>
                    <th className="px-6 py-4">Product</th>
                    <th className="px-6 py-4">Stock</th>
                    <th className="px-6 py-4">Price</th>
                    <th className="px-6 py-4">Category</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {products.map(product => (
                    <tr key={product.id} className="hover:bg-white/5 transition">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-4">
                          <img src={product.images[0]} className="w-10 h-10 rounded object-cover" alt="" />
                          <div>
                            <div className="text-white font-bold">{product.name}</div>
                            <div className="text-[10px] text-gray-500">{product.brand}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`${product.stock < 3 ? 'text-red-500' : 'text-gray-400'}`}>{product.stock} units</span>
                      </td>
                      <td className="px-6 py-4 text-[#bf953f]">{formatPrice(product.price)}</td>
                      <td className="px-6 py-4 text-gray-500">{product.category}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <button className="p-2 text-gray-500 hover:text-white transition"><Edit3 size={16} /></button>
                          <button className="p-2 text-gray-500 hover:text-red-500 transition"><Trash2 size={16} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
