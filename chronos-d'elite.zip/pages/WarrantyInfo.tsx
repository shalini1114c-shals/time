
import React from 'react';
import { Shield, FileCheck, Award, HeartHandshake } from 'lucide-react';

const WarrantyInfo: React.FC = () => {
  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-20">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Guaranteed Excellence</span>
          <h1 className="text-4xl md:text-6xl italic serif mb-8">Warranty Information</h1>
          <p className="text-gray-500 font-light text-lg leading-relaxed">
            Your confidence is our priority. Every Chronos d'Elite timepiece is backed by a robust international guarantee.
          </p>
        </header>

        <div className="grid grid-cols-1 gap-12">
          <div className="border border-white/5 bg-neutral-900/20 p-12 rounded-lg">
            <Award className="text-[#bf953f] mb-8" size={40} />
            <h2 className="text-3xl italic serif mb-6">International Limited Warranty</h2>
            <div className="space-y-6 text-gray-400 font-light leading-relaxed">
              <p>Chronos d'Elite warrants its timepieces for a period of five (5) years from the original date of purchase. This warranty covers manufacturing defects in the movement and craftsmanship of the watch.</p>
              <div className="pl-6 border-l-2 border-[#bf953f]/30 space-y-4">
                <p className="text-sm uppercase tracking-widest text-white">Coverage Includes:</p>
                <ul className="list-disc pl-5 text-xs space-y-2 uppercase tracking-[0.2em]">
                  <li>Internal movement defects</li>
                  <li>Dial and hand abnormalities</li>
                  <li>Manufacturing issues with the case</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-neutral-900/40 p-10 border border-white/5">
              <FileCheck className="text-[#bf953f] mb-6" />
              <h3 className="text-lg font-bold uppercase tracking-widest mb-4">Registration</h3>
              <p className="text-xs text-gray-500 leading-relaxed">Register your timepiece within 30 days of purchase to activate your extended 2-year manufacturer's guarantee for a total of 7 years of protection.</p>
            </div>
            <div className="bg-neutral-900/40 p-10 border border-white/5">
              <HeartHandshake className="text-[#bf953f] mb-6" />
              <h3 className="text-lg font-bold uppercase tracking-widest mb-4">Transferability</h3>
              <p className="text-xs text-gray-500 leading-relaxed">Our warranty follows the watch, not the owner. Should you pass on your timepiece, the remaining warranty is fully transferable.</p>
            </div>
          </div>

          <div className="mt-12 text-center text-gray-600 text-[10px] uppercase tracking-[0.4em]">
            Terms and conditions apply. Damage resulting from accidents or improper use is not covered.
          </div>
        </div>
      </div>
    </div>
  );
};

export default WarrantyInfo;
