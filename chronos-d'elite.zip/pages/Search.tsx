
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { products } from '../data/products';
import { Search as SearchIcon, X, ArrowRight, ShoppingBag } from 'lucide-react';
import { useApp } from '../context/AppContext';

const Search: React.FC = () => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const { addToCart, formatPrice } = useApp();

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    const lowerQuery = query.toLowerCase();
    return products.filter(p => 
      p.name.toLowerCase().includes(lowerQuery) ||
      p.brand.toLowerCase().includes(lowerQuery) ||
      p.category.toLowerCase().includes(lowerQuery) ||
      p.description.toLowerCase().includes(lowerQuery)
    );
  }, [query]);

  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Search Header */}
        <div className="mb-20 text-center">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-6 block">Search Our Collection</span>
          <div className="relative max-w-3xl mx-auto">
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by brand, model, or style..."
              className="w-full bg-transparent border-b border-white/20 py-6 text-2xl md:text-4xl font-light focus:border-[#bf953f] outline-none transition-colors placeholder:text-neutral-800 text-white"
            />
            {query && (
              <button 
                onClick={() => setQuery('')}
                className="absolute right-0 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition"
              >
                <X size={32} />
              </button>
            )}
          </div>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <span className="text-[10px] uppercase tracking-widest text-gray-500">Popular:</span>
            {['Rolex', 'Patek Philippe', 'Royal Oak', 'Sport', 'Gold'].map(tag => (
              <button 
                key={tag}
                onClick={() => setQuery(tag)}
                className="text-[10px] uppercase tracking-widest text-[#bf953f] hover:text-white transition border border-[#bf953f]/30 px-3 py-1 rounded-full"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Results */}
        {query.trim() ? (
          <div>
            <div className="flex justify-between items-center mb-12 pb-4 border-b border-white/5">
              <h2 className="text-xl italic serif">{searchResults.length} Results for "{query}"</h2>
              <p className="text-[10px] uppercase tracking-widest text-gray-500">Chronos d'Elite Inventory</p>
            </div>

            {searchResults.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
                {searchResults.map(product => (
                  <div key={product.id} className="group">
                    <Link to={`/product/${product.id}`} className="block relative aspect-[4/5] bg-neutral-900 overflow-hidden mb-6">
                      <img 
                        src={product.images[0]} 
                        alt={product.name}
                        className="w-full h-full object-cover transition duration-1000 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition duration-500"></div>
                    </Link>
                    <div className="flex flex-col">
                      <span className="text-[10px] tracking-widest uppercase text-gray-500 mb-1">{product.brand}</span>
                      <h3 className="text-lg text-white mb-2 group-hover:text-[#bf953f] transition">
                        <Link to={`/product/${product.id}`}>{product.name}</Link>
                      </h3>
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-light text-[#bf953f] tracking-widest">{formatPrice(product.price)}</span>
                        <button 
                          onClick={() => addToCart(product)}
                          className="p-2 text-gray-500 hover:text-[#bf953f] transition"
                          title="Add to Collection"
                        >
                          <ShoppingBag size={18} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-neutral-900/10 rounded-lg border border-white/5">
                <p className="text-gray-500 text-lg mb-4 italic serif">No timepieces found matching your search.</p>
                <button 
                  onClick={() => setQuery('')}
                  className="text-[#bf953f] uppercase tracking-widest text-xs font-bold border-b border-[#bf953f] pb-1"
                >
                  Clear search and browse all
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-20">
            <SearchIcon size={48} className="mx-auto text-neutral-800 mb-6" />
            <p className="text-neutral-500 uppercase tracking-[0.3em] text-xs">Enter a search term to begin exploring</p>
          </div>
        )}

        {/* Suggested Categories */}
        {!query && (
          <div className="mt-20">
            <h3 className="text-center text-[10px] uppercase tracking-[0.5em] text-gray-600 mb-12">Suggested Categories</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Link to="/shop?collection=Men" className="relative h-64 group overflow-hidden bg-neutral-900">
                <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover opacity-50 transition group-hover:scale-110 group-hover:opacity-70" alt="Men" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-white text-xl uppercase tracking-widest font-bold border-b border-transparent group-hover:border-white transition pb-1">Men's</span>
                </div>
              </Link>
              <Link to="/shop?collection=Women" className="relative h-64 group overflow-hidden bg-neutral-900">
                <img src="https://images.unsplash.com/photo-1509048191080-d2984bad6ad5?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover opacity-50 transition group-hover:scale-110 group-hover:opacity-70" alt="Women" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-white text-xl uppercase tracking-widest font-bold border-b border-transparent group-hover:border-white transition pb-1">Women's</span>
                </div>
              </Link>
              <Link to="/shop?category=Limited" className="relative h-64 group overflow-hidden bg-neutral-900">
                <img src="https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?auto=format&fit=crop&q=80&w=800" className="w-full h-full object-cover opacity-50 transition group-hover:scale-110 group-hover:opacity-70" alt="Limited" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-white text-xl uppercase tracking-widest font-bold border-b border-transparent group-hover:border-white transition pb-1">Limited</span>
                </div>
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Search;
