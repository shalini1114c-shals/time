
import React from 'react';
import { Truck, RotateCcw, ShieldCheck, Globe } from 'lucide-react';

const ShippingReturns: React.FC = () => {
  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-20">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Concierge Logistics</span>
          <h1 className="text-4xl md:text-6xl italic serif mb-8">Shipping & Returns</h1>
          <p className="text-gray-500 font-light text-lg leading-relaxed">
            Every delivery is handled with the utmost discretion and care, ensuring your timepiece arrives in pristine condition.
          </p>
        </header>

        <div className="space-y-16">
          <section>
            <div className="flex items-center gap-4 mb-8">
              <Truck className="text-[#bf953f]" />
              <h2 className="text-2xl italic serif">Complimentary Express Shipping</h2>
            </div>
            <div className="prose prose-invert max-w-none text-gray-400 font-light leading-relaxed">
              <p className="mb-4">We offer complimentary insured express shipping on all orders globally. All shipments require an adult signature upon delivery to ensure security.</p>
              <ul className="list-disc pl-5 space-y-2 text-sm uppercase tracking-widest">
                <li>Europe & UK: 1-2 Business Days</li>
                <li>North America: 2-3 Business Days</li>
                <li>Asia & Middle East: 3-5 Business Days</li>
                <li>India: 2-4 Business Days</li>
              </ul>
            </div>
          </section>

          <section>
            <div className="flex items-center gap-4 mb-8">
              <RotateCcw className="text-[#bf953f]" />
              <h2 className="text-2xl italic serif">The Return Process</h2>
            </div>
            <div className="prose prose-invert max-w-none text-gray-400 font-light leading-relaxed">
              <p className="mb-4">Should you wish to return your purchase, we offer a complimentary 30-day return policy. The timepiece must be in its original, unworn condition with all protective seals intact.</p>
              <p className="text-sm italic">Note: Special orders and personalized engravings are non-returnable.</p>
            </div>
          </section>

          <section className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-12 border-t border-white/10">
            <div className="flex gap-4">
              <ShieldCheck className="text-[#bf953f] shrink-0" />
              <div>
                <h4 className="text-sm font-bold uppercase tracking-widest text-white mb-2">Fully Insured</h4>
                <p className="text-xs text-gray-500">Your shipment is insured at its full value from the moment it leaves our vault until it reaches your hands.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <Globe className="text-[#bf953f] shrink-0" />
              <div>
                <h4 className="text-sm font-bold uppercase tracking-widest text-white mb-2">Customs & Duties</h4>
                <p className="text-xs text-gray-500">For international orders, all duties and taxes are calculated and collected at checkout for a seamless experience.</p>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default ShippingReturns;
