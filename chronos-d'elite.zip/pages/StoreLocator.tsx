
import React from 'react';
import { MapPin, Navigation, Phone, Calendar } from 'lucide-react';

const StoreLocator: React.FC = () => {
  const stores = [
    {
      city: 'Geneva',
      name: 'Maison Chronos Geneva',
      address: 'Rue du Rhône 42, 1204 Genève, Switzerland',
      phone: '+41 22 555 0123',
      hours: 'Mon-Sat: 10:00 - 19:00'
    },
    {
      city: 'Mumbai',
      name: 'The Chronos Salon',
      address: 'Taj Mahal Palace, Apollo Bunder, Mumbai 400001',
      phone: '+91 22 666 5333',
      hours: 'Mon-Sun: 11:00 - 20:00'
    },
    {
      city: 'London',
      name: 'Elite Boutique Mayfair',
      address: '16 New Bond St, London W1S 3SU, UK',
      phone: '+44 20 7493 0000',
      hours: 'Mon-Sat: 10:00 - 18:30'
    },
    {
      city: 'New York',
      name: 'Fifth Avenue Flagship',
      address: '712 5th Ave, New York, NY 10019, USA',
      phone: '+1 212 555 9000',
      hours: 'Mon-Sun: 10:00 - 19:00'
    }
  ];

  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-20">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Visit Our Salons</span>
          <h1 className="text-4xl md:text-6xl italic serif mb-8">Store Locator</h1>
          <p className="text-gray-500 font-light text-lg max-w-2xl mx-auto">
            Experience the weight and brilliance of our collection in person. Private viewings available by appointment.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Mock Map View */}
          <div className="bg-neutral-900 border border-white/5 aspect-square lg:aspect-auto rounded-lg overflow-hidden relative group">
            <img 
              src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=1200" 
              className="w-full h-full object-cover opacity-40 grayscale group-hover:scale-110 transition duration-[20s]" 
              alt="Map Background" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="flex flex-col items-center">
                <MapPin className="text-[#bf953f] animate-bounce mb-2" size={48} />
                <span className="bg-black/80 backdrop-blur px-4 py-2 rounded text-[10px] font-bold uppercase tracking-widest text-white border border-[#bf953f]/30">Global Presence</span>
              </div>
            </div>
          </div>

          {/* Stores List */}
          <div className="space-y-6">
            {stores.map((store, idx) => (
              <div key={idx} className="bg-neutral-900/50 p-8 border border-white/5 hover:border-[#bf953f]/30 transition group">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <span className="text-[#bf953f] text-[10px] font-bold uppercase tracking-[0.3em] mb-2 block">{store.city}</span>
                    <h3 className="text-xl italic serif text-white">{store.name}</h3>
                  </div>
                  <button className="p-3 border border-white/10 rounded-full text-gray-500 group-hover:text-white group-hover:border-white transition">
                    <Navigation size={18} />
                  </button>
                </div>
                
                <div className="space-y-4 mb-8">
                  <p className="text-sm text-gray-400 font-light">{store.address}</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <Phone size={14} /> <span>{store.phone}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <Calendar size={14} /> <span>{store.hours}</span>
                  </div>
                </div>

                <button className="w-full py-4 border border-white/10 text-[10px] font-bold uppercase tracking-widest hover:bg-white/5 transition">
                  Book Appointment
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoreLocator;
