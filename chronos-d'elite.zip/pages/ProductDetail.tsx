
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { products } from '../data/products';
import { useApp } from '../context/AppContext';
import { Heart, ShoppingBag, Shield, Clock, RotateCcw, Plus, Minus, Check } from 'lucide-react';

const ProductDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, toggleWishlist, wishlist, formatPrice, addToRecentlyViewed, recentlyViewed } = useApp();
  const [activeImg, setActiveImg] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedFeedback, setAddedFeedback] = useState(false);
  const [wishlistFeedback, setWishlistFeedback] = useState<string | null>(null);
  
  const product = products.find(p => p.id === id);

  useEffect(() => {
    if (product) {
      addToRecentlyViewed(product.id);
    }
  }, [id, product]);

  if (!product) return <div className="pt-32 text-center text-white font-light uppercase tracking-widest">Timepiece not found.</div>;

  const isWishlisted = wishlist.includes(product.id);
  const related = products.filter(p => p.id !== product.id && p.category === product.category).slice(0, 3);
  const recentlyViewedProducts = products.filter(p => recentlyViewed.includes(p.id) && p.id !== product.id).slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setAddedFeedback(true);
    setTimeout(() => setAddedFeedback(false), 2000);
  };

  const handleToggleWishlist = () => {
    toggleWishlist(product.id);
    const message = isWishlisted ? "Removed from Wishlist" : "Added to Wishlist";
    setWishlistFeedback(message);
    setTimeout(() => setWishlistFeedback(null), 2500);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    navigate('/cart');
  };

  return (
    <div className="pt-32 pb-24 px-4 bg-black relative">
      {/* Wishlist Toast Notification */}
      {wishlistFeedback && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] bg-[#bf953f] text-black px-6 py-3 rounded-full font-bold uppercase tracking-widest text-[10px] luxury-shadow animate-in fade-in slide-in-from-top-4 duration-300">
          {wishlistFeedback}
        </div>
      )}

      <div className="max-w-7xl mx-auto">
        <nav className="flex items-center text-[10px] uppercase tracking-widest text-gray-500 mb-12 space-x-2">
          <Link to="/" className="hover:text-white transition">Home</Link>
          <span>/</span>
          <Link to="/shop" className="hover:text-white transition">Collection</Link>
          <span>/</span>
          <span className="text-white">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-24">
          {/* Gallery */}
          <div className="space-y-4">
            <div className="aspect-[4/5] bg-neutral-900 overflow-hidden group cursor-zoom-in relative">
              <img 
                src={product.images[activeImg]} 
                alt={product.name}
                className="w-full h-full object-cover transition duration-700 group-hover:scale-125"
              />
              {product.stock < 3 && (
                <span className="absolute top-6 left-6 bg-red-600/90 text-white text-[10px] font-bold px-3 py-1 uppercase tracking-widest">
                  Only {product.stock} Remaining
                </span>
              )}
            </div>
            {product.images.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {product.images.map((img, idx) => (
                  <button 
                    key={idx}
                    onClick={() => setActiveImg(idx)}
                    className={`aspect-square overflow-hidden border-2 transition ${activeImg === idx ? 'border-[#bf953f]' : 'border-transparent opacity-50 hover:opacity-100'}`}
                  >
                    <img src={img} alt={product.name} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div className="flex flex-col">
            <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">{product.brand}</span>
            <h1 className="text-4xl md:text-5xl mb-6 leading-tight">{product.name}</h1>
            
            <div className="flex items-center gap-6 mb-8">
              <span className="text-3xl font-light text-white tracking-widest">{formatPrice(product.price)}</span>
              {product.oldPrice && (
                <span className="text-xl text-gray-600 line-through tracking-widest">{formatPrice(product.oldPrice)}</span>
              )}
            </div>

            <p className="text-gray-400 text-lg font-light leading-relaxed mb-10">
              {product.description}
            </p>

            <div className="grid grid-cols-2 gap-y-8 gap-x-12 mb-12 pb-12 border-b border-white/10">
              <div>
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">Movement</h4>
                <p className="text-sm text-white">{product.specs.movement}</p>
              </div>
              <div>
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">Case Material</h4>
                <p className="text-sm text-white">{product.specs.caseMaterial}</p>
              </div>
              <div>
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">Water Resistance</h4>
                <p className="text-sm text-white">{product.specs.waterResistance}</p>
              </div>
              <div>
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-2">Warranty</h4>
                <p className="text-sm text-white">{product.specs.warranty}</p>
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="flex flex-col mb-8">
              <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mb-4">Select Quantity</label>
              <div className="flex items-center border border-white/10 w-32 rounded">
                <button 
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="p-4 text-gray-500 hover:text-white transition"
                >
                  <Minus size={14} />
                </button>
                <span className="flex-grow text-center text-sm font-bold text-white">{quantity}</span>
                <button 
                  onClick={() => setQuantity(q => q + 1)}
                  className="p-4 text-gray-500 hover:text-white transition"
                >
                  <Plus size={14} />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-4 mb-12">
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={handleAddToCart}
                  disabled={addedFeedback}
                  className={`flex-grow h-16 flex items-center justify-center font-bold uppercase tracking-widest text-xs transition active:scale-95 gap-3 ${addedFeedback ? 'bg-green-600 text-white border-green-600' : 'bg-[#bf953f] text-black hover:bg-[#d4af37]'}`}
                >
                  {addedFeedback ? (
                    <><Check size={18} /> Added</>
                  ) : (
                    <><ShoppingBag size={18} /> Add to Collection</>
                  )}
                </button>
                <button 
                  onClick={handleToggleWishlist}
                  className={`w-16 h-16 border flex items-center justify-center transition group ${isWishlisted ? 'border-[#bf953f] bg-[#bf953f]/10 text-[#bf953f]' : 'border-white/20 text-white hover:border-white'}`}
                  title={isWishlisted ? "Remove from Wishlist" : "Add to Wishlist"}
                >
                  <Heart 
                    size={20} 
                    className={`transition-transform duration-300 group-hover:scale-110 ${isWishlisted ? 'fill-current' : 'fill-none'}`} 
                  />
                </button>
              </div>
              <button 
                onClick={handleBuyNow}
                className="w-full h-16 border border-white/20 text-white font-bold uppercase tracking-widest text-xs hover:bg-white/5 transition active:scale-95"
              >
                Buy It Now
              </button>
            </div>

            <div className="space-y-6">
              <div className="flex items-center gap-4 text-xs tracking-widest uppercase text-gray-400">
                <Shield size={16} className="text-[#bf953f]" /> <span>Insured Express Shipping</span>
              </div>
              <div className="flex items-center gap-4 text-xs tracking-widest uppercase text-gray-400">
                <Clock size={16} className="text-[#bf953f]" /> <span>Ships within 24 Hours</span>
              </div>
              <div className="flex items-center gap-4 text-xs tracking-widest uppercase text-gray-400">
                <RotateCcw size={16} className="text-[#bf953f]" /> <span>30-Day Bespoke Returns</span>
              </div>
            </div>
          </div>
        </div>

        {/* Technical Specifications */}
        <section className="py-24 border-t border-white/5">
          <h2 className="text-3xl mb-16 italic serif">Technical Specifications</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-24 gap-y-8">
            <div className="flex justify-between items-center py-4 border-b border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500">Movement</span>
              <span className="text-sm text-white">{product.specs.movement}</span>
            </div>
            <div className="flex justify-between items-center py-4 border-b border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500">Case Material</span>
              <span className="text-sm text-white">{product.specs.caseMaterial}</span>
            </div>
            <div className="flex justify-between items-center py-4 border-b border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500">Strap Material</span>
              <span className="text-sm text-white">{product.specs.strapMaterial}</span>
            </div>
            <div className="flex justify-between items-center py-4 border-b border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500">Dial Color</span>
              <span className="text-sm text-white">{product.specs.dialColor}</span>
            </div>
            <div className="flex justify-between items-center py-4 border-b border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500">Water Resistance</span>
              <span className="text-sm text-white">{product.specs.waterResistance}</span>
            </div>
            <div className="flex justify-between items-center py-4 border-b border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500">Warranty</span>
              <span className="text-sm text-white">{product.specs.warranty}</span>
            </div>
            <div className="flex justify-between items-center py-4 border-b border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500">Gender</span>
              <span className="text-sm text-white">{product.gender}</span>
            </div>
            <div className="flex justify-between items-center py-4 border-b border-white/5">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-gray-500">Reference Number</span>
              <span className="text-sm text-white">REF-{product.id.padStart(4, '0')}</span>
            </div>
          </div>
        </section>

        {/* Recently Viewed Products */}
        {recentlyViewedProducts.length > 0 && (
          <section className="py-24 border-t border-white/5">
            <div className="flex justify-between items-end mb-16">
              <div>
                <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Browsing History</span>
                <h2 className="text-3xl italic serif">Recently Viewed</h2>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {recentlyViewedProducts.map(p => (
                <Link key={p.id} to={`/product/${p.id}`} className="group">
                  <div className="aspect-[4/5] overflow-hidden mb-6 bg-neutral-900">
                    <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover transition duration-700 group-hover:scale-105" />
                  </div>
                  <h4 className="text-[10px] tracking-widest uppercase text-gray-500 mb-1">{p.brand}</h4>
                  <h3 className="text-lg mb-2 group-hover:text-[#bf953f] transition">{p.name}</h3>
                  <span className="text-sm font-bold tracking-widest">{formatPrice(p.price)}</span>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Related Products */}
        {related.length > 0 && (
          <section className="py-24 border-t border-white/5">
            <h2 className="text-3xl mb-16 italic serif">You May Also Admire</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-12">
              {related.map(p => (
                <Link key={p.id} to={`/product/${p.id}`} className="group">
                  <div className="aspect-[4/5] overflow-hidden mb-6 bg-neutral-900">
                    <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover transition duration-700 group-hover:scale-105" />
                  </div>
                  <h4 className="text-[10px] tracking-widest uppercase text-gray-500 mb-1">{p.brand}</h4>
                  <h3 className="text-lg mb-2 group-hover:text-[#bf953f] transition">{p.name}</h3>
                  <span className="text-sm font-bold tracking-widest">{formatPrice(p.price)}</span>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
