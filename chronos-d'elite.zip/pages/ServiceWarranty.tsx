
import React, { useState } from 'react';
import { Shield, Clock, Wrench, Search, CheckCircle2, AlertCircle, Calendar, ArrowRight, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

const ServiceWarranty: React.FC = () => {
  const { formatPrice } = useApp();
  const [serialNumber, setSerialNumber] = useState('');
  const [warrantyStatus, setWarrantyStatus] = useState<'idle' | 'loading' | 'active' | 'expired' | 'invalid'>('idle');
  const [activeTab, setActiveTab] = useState<'warranty' | 'service'>('warranty');

  const handleCheckWarranty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serialNumber.trim()) return;

    setWarrantyStatus('loading');
    // Simulate API call
    setTimeout(() => {
      if (serialNumber.toUpperCase().startsWith('CH')) {
        setWarrantyStatus('active');
      } else if (serialNumber.length < 5) {
        setWarrantyStatus('invalid');
      } else {
        setWarrantyStatus('expired');
      }
    }, 1500);
  };

  return (
    <div className="pt-40 pb-24 px-4 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-20">
          <span className="text-[#bf953f] text-xs tracking-[0.4em] uppercase mb-4 block">Guardian of Time</span>
          <h1 className="text-5xl md:text-7xl italic serif mb-8">Service & <span className="text-white not-italic font-sans font-bold tracking-widest">WARRANTY</span></h1>
          <p className="text-gray-500 font-light text-lg max-w-2xl mx-auto leading-relaxed">
            Protecting the heartbeat of your legacy. Our international guarantee and expert care ensure your timepiece remains a masterpiece for generations.
          </p>
        </header>

        {/* Tab Selection */}
        <div className="flex justify-center mb-16">
          <div className="inline-flex bg-neutral-900/50 p-1 rounded-full border border-white/5">
            <button 
              onClick={() => setActiveTab('warranty')}
              className={`px-8 py-3 rounded-full text-xs font-bold uppercase tracking-widest transition ${activeTab === 'warranty' ? 'bg-[#bf953f] text-black' : 'text-gray-400 hover:text-white'}`}
            >
              Warranty Check
            </button>
            <button 
              onClick={() => setActiveTab('service')}
              className={`px-8 py-3 rounded-full text-xs font-bold uppercase tracking-widest transition ${activeTab === 'service' ? 'bg-[#bf953f] text-black' : 'text-gray-400 hover:text-white'}`}
            >
              Service & Repairs
            </button>
          </div>
        </div>

        {activeTab === 'warranty' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            {/* Warranty Info */}
            <div className="space-y-12">
              <section>
                <div className="flex items-center gap-4 mb-6">
                  <ShieldCheck className="text-[#bf953f]" size={28} />
                  <h2 className="text-3xl italic serif">International Guarantee</h2>
                </div>
                <p className="text-gray-400 font-light leading-relaxed mb-6">
                  Every Chronos d'Elite timepiece is covered by a 5-year international limited warranty from the date of purchase. This covers any manufacturing defects under normal use.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="bg-neutral-900/40 p-6 border border-white/5">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#bf953f] mb-2">Extended Protection</h4>
                    <p className="text-xs text-gray-500">Register your watch online within 90 days to receive an additional 2 years of coverage.</p>
                  </div>
                  <div className="bg-neutral-900/40 p-6 border border-white/5">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#bf953f] mb-2">Global Validity</h4>
                    <p className="text-xs text-gray-500">Honored at any of our 45 global service centers or authorized retailers.</p>
                  </div>
                </div>
              </section>

              <div className="border-t border-white/5 pt-12">
                <h3 className="text-xl italic serif mb-6 text-white">What's Covered?</h3>
                <ul className="space-y-4">
                  {[
                    "Movement accuracy and defects",
                    "Case and bracelet integrity",
                    "Dial and hand alignment",
                    "Water resistance seals"
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-xs uppercase tracking-widest text-gray-500">
                      <div className="w-1 h-1 bg-[#bf953f] rounded-full"></div> {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Warranty Checker Tool */}
            <div className="bg-neutral-900/50 border border-[#bf953f]/20 p-10 rounded-lg luxury-shadow sticky top-32">
              <h3 className="text-xl font-bold uppercase tracking-widest mb-8 text-center">Warranty Status Checker</h3>
              <form onSubmit={handleCheckWarranty} className="space-y-6">
                <div>
                  <label className="block text-[10px] uppercase tracking-widest text-gray-500 mb-2">Timepiece Serial Number</label>
                  <input 
                    type="text" 
                    value={serialNumber}
                    onChange={(e) => setSerialNumber(e.target.value.toUpperCase())}
                    placeholder="e.g. CH-2024-X"
                    className="w-full bg-black border border-white/10 px-4 py-4 rounded text-sm focus:border-[#bf953f] outline-none tracking-widest"
                  />
                  <p className="text-[9px] text-gray-600 mt-2 uppercase tracking-widest">Find this on your warranty card or case back.</p>
                </div>
                <button 
                  type="submit"
                  disabled={warrantyStatus === 'loading'}
                  className="w-full h-14 gold-bg text-black font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 hover:opacity-90 transition"
                >
                  {warrantyStatus === 'loading' ? 'Consulting Registers...' : <><Search size={16} /> Check Status</>}
                </button>
              </form>

              {/* Status Display */}
              <div className="mt-10 min-h-[100px] flex items-center justify-center border-t border-white/5 pt-8">
                {warrantyStatus === 'idle' && (
                  <p className="text-xs text-gray-600 uppercase tracking-widest italic">Enter your details to verify authenticity and coverage.</p>
                )}
                {warrantyStatus === 'loading' && (
                  <div className="animate-pulse text-[#bf953f] flex items-center gap-3">
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:0.2s]"></div>
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:0.4s]"></div>
                  </div>
                )}
                {warrantyStatus === 'active' && (
                  <div className="text-center w-full animate-in fade-in slide-in-from-bottom-2">
                    <CheckCircle2 size={40} className="text-green-500 mx-auto mb-4" />
                    <h4 className="text-xl font-bold text-white uppercase tracking-widest mb-2">Status: ACTIVE</h4>
                    <p className="text-xs text-gray-400 uppercase tracking-widest">Valid until Dec 2029</p>
                    <button className="mt-6 text-[#bf953f] text-[10px] font-bold uppercase tracking-widest border-b border-[#bf953f] pb-0.5">Download Certificate</button>
                  </div>
                )}
                {warrantyStatus === 'expired' && (
                  <div className="text-center w-full animate-in fade-in">
                    <AlertCircle size={40} className="text-orange-500 mx-auto mb-4" />
                    <h4 className="text-xl font-bold text-white uppercase tracking-widest mb-2">Status: EXPIRED</h4>
                    <p className="text-xs text-gray-400 uppercase tracking-widest mb-4">Coverage ended in 2023</p>
                    <button onClick={() => setActiveTab('service')} className="text-[#bf953f] text-[10px] font-bold uppercase tracking-widest border-b border-[#bf953f] pb-0.5">Extend Coverage</button>
                  </div>
                )}
                {warrantyStatus === 'invalid' && (
                  <div className="text-center w-full animate-in zoom-in-95">
                    <AlertCircle size={40} className="text-red-500 mx-auto mb-4" />
                    <h4 className="text-xl font-bold text-white uppercase tracking-widest mb-2">Invalid Serial</h4>
                    <p className="text-xs text-gray-400 uppercase tracking-widest">Please verify the number on your timepiece.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
             {/* Service Intervals */}
             <div className="space-y-16">
                <section>
                  <div className="flex items-center gap-4 mb-6">
                    <Wrench className="text-[#bf953f]" size={28} />
                    <h2 className="text-3xl italic serif">Maintenance Lifecycle</h2>
                  </div>
                  <p className="text-gray-400 font-light leading-relaxed mb-10">
                    A masterpiece of micro-engineering requires precision care. Follow our recommended timeline to ensure peak performance for decades.
                  </p>
                  
                  <div className="space-y-8 relative">
                    <div className="absolute left-4 top-0 bottom-0 w-px bg-white/10 ml-[7px]"></div>
                    {[
                      { year: 'Every 2 Years', title: 'Water Resistance Check', desc: 'Gasket inspection and pressure testing to ensure integrity.' },
                      { year: 'Every 5 Years', title: 'Complete Overhaul', desc: 'Disassembly, cleaning, lubrication, and movement calibration.' },
                      { year: 'As Desired', title: 'Bespoke Polishing', desc: 'Restoring the original finish of gold and platinum cases.' }
                    ].map((step, i) => (
                      <div key={i} className="relative pl-12">
                        <div className="absolute left-0 top-1 w-4 h-4 rounded-full bg-black border-2 border-[#bf953f] z-10"></div>
                        <span className="text-[#bf953f] text-[10px] font-bold uppercase tracking-widest mb-1 block">{step.year}</span>
                        <h4 className="text-lg text-white mb-2">{step.title}</h4>
                        <p className="text-sm text-gray-500 leading-relaxed font-light">{step.desc}</p>
                      </div>
                    ))}
                  </div>
                </section>

                <div className="bg-neutral-900/30 p-8 border border-white/5">
                  <h3 className="text-lg italic serif mb-4 text-white">White-Glove Collection</h3>
                  <p className="text-xs text-gray-500 leading-relaxed uppercase tracking-widest mb-6">
                    We offer complimentary insured courier collection and return for all servicing within Europe, North America, and India.
                  </p>
                  <button className="text-[#bf953f] text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 group">
                    View Logistics <ArrowRight size={14} className="group-hover:translate-x-1 transition" />
                  </button>
                </div>
             </div>

             {/* Service Request Card */}
             <div className="bg-neutral-900/50 border border-[#bf953f]/20 p-10 rounded-lg luxury-shadow">
                <h3 className="text-xl font-bold uppercase tracking-widest mb-8 text-center">Book a Master Service</h3>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] uppercase tracking-widest text-gray-500 mb-2">Timepiece Model</label>
                      <select className="w-full bg-black border border-white/10 px-4 py-4 rounded text-xs focus:border-[#bf953f] outline-none text-white appearance-none">
                        <option>Select Model</option>
                        <option>Royal Oak</option>
                        <option>Nautilus</option>
                        <option>Daytona</option>
                        <option>Other / Vintage</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase tracking-widest text-gray-500 mb-2">Service Type</label>
                      <select className="w-full bg-black border border-white/10 px-4 py-4 rounded text-xs focus:border-[#bf953f] outline-none text-white appearance-none">
                        <option>Full Overhaul</option>
                        <option>Polishing</option>
                        <option>Battery/Quartz</option>
                        <option>Restoration</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-widest text-gray-500 mb-2">Describe the Issue</label>
                    <textarea 
                      className="w-full h-32 bg-black border border-white/10 px-4 py-4 rounded text-xs focus:border-[#bf953f] outline-none text-white resize-none"
                      placeholder="e.g. Movement is running 5 seconds slow per day..."
                    ></textarea>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-gray-400 font-light">
                    <Calendar size={18} className="text-[#bf953f]" />
                    <span>Estimated processing time: 4-6 weeks</span>
                  </div>
                  <button className="w-full h-14 gold-bg text-black font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-2 hover:opacity-90 transition">
                    Request Concierge Service
                  </button>
                  <p className="text-center text-[9px] text-gray-600 uppercase tracking-widest">Our experts will contact you within 24 hours to confirm logistics.</p>
                </div>
             </div>
          </div>
        )}

        {/* Global Network Section */}
        <section className="mt-32 pt-20 border-t border-white/5">
          <div className="text-center mb-16">
            <h2 className="text-4xl italic serif mb-4">Our Global Presence</h2>
            <p className="text-gray-500 text-xs uppercase tracking-[0.4em]">Expert care, wherever you are</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { loc: 'Geneva', type: 'Grand Atelier' },
              { loc: 'Mumbai', type: 'Service Salon' },
              { loc: 'New York', type: 'Master Boutique' },
              { loc: 'Tokyo', type: 'Certified Center' }
            ].map((node, i) => (
              <div key={i} className="text-center group cursor-pointer">
                <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center mx-auto mb-4 group-hover:border-[#bf953f] transition">
                  <div className="w-2 h-2 bg-[#bf953f] rounded-full"></div>
                </div>
                <h4 className="text-sm font-bold uppercase tracking-widest mb-1">{node.loc}</h4>
                <p className="text-[10px] text-gray-600 uppercase tracking-widest">{node.type}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ServiceWarranty;
