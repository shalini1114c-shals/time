
export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  oldPrice?: number;
  gender: 'Men' | 'Women' | 'Unisex';
  category: 'Classic' | 'Sport' | 'Luxury' | 'Limited Edition';
  images: string[];
  description: string;
  specs: {
    movement: string;
    caseMaterial: string;
    waterResistance: string;
    strapMaterial: string;
    dialColor: string;
    warranty: string;
  };
  stock: number;
  featured?: boolean;
  bestSeller?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  addresses: Address[];
}

export interface Address {
  id: string;
  fullName: string;
  street: string;
  city: string;
  country: string;
  zipCode: string;
  isDefault: boolean;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'shipped' | 'delivered' | 'cancelled';
  paymentStatus: 'paid' | 'pending' | 'failed';
  createdAt: string;
  address: Address;
}

export interface AnalyticsData {
  name: string;
  revenue: number;
  orders: number;
}
