
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-950 border-t border-white/5 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex flex-col mb-6">
              <span className="text-xl font-bold tracking-[0.3em] uppercase gold-gradient">CHRONOS</span>
              <span className="text-[8px] tracking-[0.5em] text-gray-500 -mt-1">D'ELITE</span>
            </Link>
            <p className="text-gray-500 text-sm leading-relaxed">
              Curating the world's most exceptional timepieces since 1924. Experience horological excellence like never before.
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-semibold uppercase tracking-widest text-xs mb-6">Collections</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li><Link to="/shop?collection=Men" className="hover:text-[#bf953f] transition">Men's Watches</Link></li>
              <li><Link to="/shop?collection=Women" className="hover:text-[#bf953f] transition">Women's Watches</Link></li>
              <li><Link to="/shop?category=Luxury" className="hover:text-[#bf953f] transition">High Jewellery</Link></li>
              <li><Link to="/shop?category=Limited" className="hover:text-[#bf953f] transition">Limited Editions</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold uppercase tracking-widest text-xs mb-6">Customer Care</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li><Link to="/service-warranty" className="hover:text-[#bf953f] transition">Service & Warranty</Link></li>
              <li><Link to="/authenticity" className="hover:text-[#bf953f] transition">Authenticity & Certification</Link></li>
              <li><Link to="/shipping-returns" className="hover:text-[#bf953f] transition">Shipping & Returns</Link></li>
              <li><Link to="/stores" className="hover:text-[#bf953f] transition">Store Locator</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold uppercase tracking-widest text-xs mb-6">Newsletter</h4>
            <p className="text-gray-500 text-xs mb-4">Subscribe to receive updates on new launches and exclusive offers.</p>
            <form className="flex">
              <input 
                type="email" 
                placeholder="EMAIL ADDRESS" 
                className="bg-transparent border-b border-white/20 py-2 text-xs focus:border-[#bf953f] outline-none flex-grow"
              />
              <button type="submit" className="ml-4 text-xs font-bold uppercase tracking-widest text-[#bf953f]">Join</button>
            </form>
            <div className="flex space-x-4 mt-8">
              <a href="#" className="text-gray-500 hover:text-white transition"><Instagram size={18} /></a>
              <a href="#" className="text-gray-500 hover:text-white transition"><Facebook size={18} /></a>
              <a href="#" className="text-gray-500 hover:text-white transition"><Twitter size={18} /></a>
              <a href="#" className="text-gray-500 hover:text-white transition"><Youtube size={18} /></a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center text-[10px] text-gray-600 uppercase tracking-[0.2em]">
          <p>© 2024 Chronos d'Elite. All Rights Reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link to="#" className="hover:text-white">Privacy Policy</Link>
            <Link to="#" className="hover:text-white">Terms of Service</Link>
            <Link to="#" className="hover:text-white">Cookie Settings</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
