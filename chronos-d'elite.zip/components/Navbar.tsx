
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { ShoppingBag, User, Heart, Menu, X, Search as SearchIcon, Globe } from 'lucide-react';

const Navbar: React.FC = () => {
  const { cart, user, currency, setCurrency } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [isBouncing, setIsBouncing] = useState(false);
  const prevCartCount = useRef(0);
  const navigate = useNavigate();

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  useEffect(() => {
    if (cartCount > prevCartCount.current) {
      setIsBouncing(true);
      const timer = setTimeout(() => setIsBouncing(false), 500);
      return () => clearTimeout(timer);
    }
    prevCartCount.current = cartCount;
  }, [cartCount]);

  return (
    <nav className="fixed w-full z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden text-white p-2"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <div className="hidden md:flex space-x-8">
              <Link to="/shop" className="text-gray-300 hover:text-white transition uppercase text-xs tracking-widest font-semibold">Shop</Link>
              <Link to="/shop?collection=Men" className="text-gray-300 hover:text-white transition uppercase text-xs tracking-widest font-semibold">Men</Link>
              <Link to="/shop?collection=Women" className="text-gray-300 hover:text-white transition uppercase text-xs tracking-widest font-semibold">Women</Link>
            </div>
          </div>

          <Link to="/" className="flex flex-col items-center">
            <span className="text-2xl md:text-3xl font-bold tracking-[0.3em] uppercase gold-gradient">CHRONOS</span>
            <span className="text-[10px] tracking-[0.5em] text-gray-500 -mt-1">D'ELITE</span>
          </Link>

          <div className="flex items-center space-x-4 md:space-x-6">
            <div className="hidden sm:flex items-center gap-1 border border-white/10 rounded-full px-2 py-1">
              <button 
                onClick={() => setCurrency('USD')}
                className={`text-[9px] font-bold px-2 py-0.5 rounded-full transition ${currency === 'USD' ? 'bg-[#bf953f] text-black' : 'text-gray-500 hover:text-white'}`}
              >
                USD
              </button>
              <button 
                onClick={() => setCurrency('INR')}
                className={`text-[9px] font-bold px-2 py-0.5 rounded-full transition ${currency === 'INR' ? 'bg-[#bf953f] text-black' : 'text-gray-500 hover:text-white'}`}
              >
                INR
              </button>
            </div>
            <Link to="/search" className="text-gray-300 hover:text-white transition">
              <SearchIcon size={18} />
            </Link>
            <Link to="/wishlist" className="text-gray-300 hover:text-white transition relative">
              <Heart size={18} />
            </Link>
            <Link to={user ? "/profile" : "/login"} className="text-gray-300 hover:text-white transition">
              <User size={18} />
            </Link>
            <Link to="/cart" className={`text-gray-300 hover:text-white transition relative ${isBouncing ? 'animate-subtle-bounce' : ''}`}>
              <ShoppingBag size={18} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#bf953f] text-black text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-black border-t border-white/10 px-4 py-6 space-y-4 animate-in slide-in-from-top">
          <Link to="/shop" onClick={() => setIsOpen(false)} className="block text-gray-300 hover:text-white uppercase tracking-widest text-sm">Shop All</Link>
          <Link to="/shop?collection=Men" onClick={() => setIsOpen(false)} className="block text-gray-300 hover:text-white uppercase tracking-widest text-sm">Men's Collection</Link>
          <Link to="/shop?collection=Women" onClick={() => setIsOpen(false)} className="block text-gray-300 hover:text-white uppercase tracking-widest text-sm">Women's Collection</Link>
          <div className="pt-4 border-t border-white/5 flex gap-4">
             <button onClick={() => setCurrency('USD')} className={`text-xs tracking-widest uppercase font-bold ${currency === 'USD' ? 'text-[#bf953f]' : 'text-gray-500'}`}>USD</button>
             <button onClick={() => setCurrency('INR')} className={`text-xs tracking-widest uppercase font-bold ${currency === 'INR' ? 'text-[#bf953f]' : 'text-gray-500'}`}>INR</button>
          </div>
          {user?.role === 'admin' && (
            <Link to="/admin" onClick={() => setIsOpen(false)} className="block text-[#bf953f] uppercase tracking-widest text-sm font-bold pt-2">Admin Dashboard</Link>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
