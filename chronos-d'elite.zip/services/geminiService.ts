
import { GoogleGenAI, Type } from "@google/genai";
import { Product } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getWatchRecommendation(userStyle: string, products: Product[]) {
  const prompt = `
    You are a luxury watch concierge at "Chronos d'Elite". 
    A customer says: "${userStyle}".
    
    Based on our current inventory:
    ${JSON.stringify(products.map(p => ({ id: p.id, name: p.name, brand: p.brand, description: p.description, price: p.price })))}
    
    Recommend the top 2 watches from our inventory that match their style. 
    Explain WHY they match in a sophisticated, luxury-brand tone.
    Provide the response in a JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  productId: { type: Type.STRING },
                  reason: { type: Type.STRING }
                },
                required: ["productId", "reason"]
              }
            },
            conciergeMessage: { type: Type.STRING }
          },
          required: ["recommendations", "conciergeMessage"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
}
