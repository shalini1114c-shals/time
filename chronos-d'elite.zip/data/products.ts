
import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Royal Oak Perpetual Calendar',
    brand: 'Audemars Piguet',
    price: 95000,
    oldPrice: 105000,
    gender: 'Men',
    category: 'Luxury',
    images: [
      'https://images.unsplash.com/photo-1547996160-81dfa63595aa?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&q=80&w=800'
    ],
    description: 'A masterpiece of complications, featuring an ultra-thin automatic movement and an iconic octagonal bezel.',
    specs: {
      movement: 'Self-winding automatic',
      caseMaterial: '18k Pink Gold',
      waterResistance: '20m',
      strapMaterial: '18k Pink Gold Bracelet',
      dialColor: 'Blue Grande Tapisserie',
      warranty: '5 Years'
    },
    stock: 2,
    featured: true
  },
  {
    id: '2',
    name: 'Nautilus 5711/1A',
    brand: 'Patek Philippe',
    price: 125000,
    gender: 'Men',
    category: 'Limited Edition',
    images: [
      'https://images.unsplash.com/photo-1508685096489-7aac2914b2b3?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&q=80&w=800'
    ],
    description: 'The pinnacle of sports elegance. A legendary design that has defined the luxury steel watch category for decades.',
    specs: {
      movement: 'Caliber 26-330 S C',
      caseMaterial: 'Stainless Steel',
      waterResistance: '120m',
      strapMaterial: 'Stainless Steel',
      dialColor: 'Olive Green Sunburst',
      warranty: '2 Years'
    },
    stock: 1,
    bestSeller: true
  },
  {
    id: '3',
    name: 'Daytona Cosmograph',
    brand: 'Rolex',
    price: 34500,
    gender: 'Men',
    category: 'Sport',
    images: [
      'https://images.unsplash.com/photo-1587836374828-4dbaba94ee0e?auto=format&fit=crop&q=80&w=800'
    ],
    description: 'Engineered for performance. The ultimate tool watch for those with a passion for driving and speed.',
    specs: {
      movement: 'Calibre 4130',
      caseMaterial: 'Oystersteel',
      waterResistance: '100m',
      strapMaterial: 'Oyster Bracelet',
      dialColor: 'Black Panda',
      warranty: '5 Years'
    },
    stock: 5,
    featured: true
  },
  {
    id: '4',
    name: 'Constellation Manhattan',
    brand: 'Omega',
    price: 12800,
    gender: 'Women',
    category: 'Luxury',
    images: [
      'https://images.unsplash.com/photo-1612817159949-195b6eb9e31a?auto=format&fit=crop&q=80&w=800'
    ],
    description: 'Defined by its famous "claws", this timepiece represents timeless elegance and precision.',
    specs: {
      movement: 'Master Chronometer 8700',
      caseMaterial: 'Sedna Gold',
      waterResistance: '50m',
      strapMaterial: 'Leather',
      dialColor: 'Mother of Pearl',
      warranty: '5 Years'
    },
    stock: 10,
    bestSeller: true
  },
  {
    id: '5',
    name: 'Tank Américaine',
    brand: 'Cartier',
    price: 15400,
    gender: 'Women',
    category: 'Classic',
    images: [
      'https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?auto=format&fit=crop&q=80&w=800'
    ],
    description: 'The Tank Américaine features an elongated case with a more pronounced curve than the original model.',
    specs: {
      movement: 'Quartz',
      caseMaterial: 'Rose Gold',
      waterResistance: '30m',
      strapMaterial: 'Alligator Skin',
      dialColor: 'Silvered Flinqué',
      warranty: '8 Years'
    },
    stock: 4
  },
  {
    id: '6',
    name: 'Submariner Date',
    brand: 'Rolex',
    price: 10500,
    gender: 'Men',
    category: 'Sport',
    images: [
      'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?auto=format&fit=crop&q=80&w=800'
    ],
    description: 'The archetype of the divers’ watch. Reliable and robust, it has evolved for over 60 years.',
    specs: {
      movement: 'Calibre 3235',
      caseMaterial: 'Oystersteel',
      waterResistance: '300m',
      strapMaterial: 'Oyster Bracelet',
      dialColor: 'Cerachrom Black',
      warranty: '5 Years'
    },
    stock: 8
  }
];
